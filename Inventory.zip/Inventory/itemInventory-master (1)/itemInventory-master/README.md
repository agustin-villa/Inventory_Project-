# itemInventory

An item inventory application that will feature 2 users: Employee and Admin 
The application will have one admin and as many as needed employees 
The application will feature a login screen for admins and employees

Admin: -All employee functions 
-Receive alerts when low on an item's stock 
-Order more of an item 
-Add new items 
-Add new users to application

Employee: -Add to an item's stock 
-Subtract from an item's stock
